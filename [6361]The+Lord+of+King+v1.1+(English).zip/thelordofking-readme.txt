--------------------------------------------
-BlackPaladins's The Lord of King NES Patch-
--------------------------------------------

******************
*The Lord of King*
******************

I was curious about this game, so I looked into making a translation patch from this platformer.  For those who are unaware, this game was released in English as "Astyanax", which was also based on an arcade game of the same name.

Patching Instructions:

This patch comes in four flavors:

The Lord of King (English).ips (English Patch in IPS Format; apply to JPN ROM)
The Lord of King (English).bps (English Patch in BPS Format; apply to JPN ROM)

The Lord of King B (English).ips (English Patch in IPS Format; apply to USA ROM)
The Lord of King B (English).bps (English Patch in BPS Format; apply to USA ROM)

I suggest using Lunar IPS for patch.  Use either patch, according to your personal preference.

Use either IPS or BPS "The Lord of King" patch to the Japanese version of the ROM.  (Don't use both patches.)

File SHA-1: 9945B83BC322872BF309A580BD56C60B747D3C25
File CRC32: 3E0C98BB
ROM SHA-1: 859D4FDF229533A13DD1C75D6785E1F2D3CB2FA9
ROM CRC32: D0EB749F

Use either IPS or BPS "The Lord of King B" patch to the American version of the ROM. (Don't use both patches.)

File SHA-1: 684D5C6DD88DF406AF2EE8F4B56EFB713E065D03
File CRC32: BEF556D1
ROM SHA-1: AC57D9DBE0AB3EBD74808FB51CBA1656955E702F
ROM CRC32: 54CB4EB

What changes have been done

v1.1

Game's script has been translated by PSXCraver.  (Thanks for helping out!)

v1.0

First release, the game's script was initially translated using DeepL, 10Ten, and Google Translator.

Special Thanks:
PSXCraver (Thank you for translating the game's script!)
MESEN Team (Used Hex Editor in MESEN Emulator)
FCE Ultra Team (Used Hex Editor in FCE Ultra Emulator)
Whipon (Beta Tester)

All credit to "The Lord of King" belong to Jaleco and their respective creators and programers.  This patch is mainly used for pure enjoyment for those who cannot enjoy this game.  All rights reserved.  (Please, don't come after me, Jaleco!)