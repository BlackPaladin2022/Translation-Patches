-------------------------------------------------------------
-BlackPaladin's Super Dimensional Fortress Macross NES Patch-
-------------------------------------------------------------

***************************
*Chou-Jikuu Yousai Macross*
***************************

I made another patch out of boredom while waiting for other translation work to be checked on.  This time, I did one for the NES/Famicom game, "Chou-Jikuu Yousai Macross" (Super Dimensional Fortress Macross).  This was one of three anime series that made up the show, "Robotech" in the 1980's.

Patching Instructions:

This patch comes in two flavors:

Super-Dimensional Fortress Macross (English).ips (English Patch in IPS Format)
Super-Dimensional Fortress Macross (English).bps (English Patch in BPS Format)

Be sure to use either IPS or BPS patch (not both) on a ROM with the following hashes...

File SHA-1: F56820E3DD7D97EABDB226249227205765886B0B
File CRC32: EF90CB84
ROM SHA-1: E8FF6B1C3A15464F792A114F16967A5DC38B9A4D
ROM CRC32: C1D7AB1D

What changes have been done:

Title Screen translated, of course
Font Changed to a more futuristic font

Special Thanks:

MESEN Team (Used Hex Editor in MESEN Emulator)
FCE Ultra Team (Used Hex Editor in FCE Ultra Emulator)
Shouji Kawamori (He created Robotech)
Namco (Programmer for the Famicom game)

All credit to "Super Dimensional Fortress Macross" belong to Namco and their respective creators and programers.  This patch is mainly used for pure enjoyment for those who cannot enjoy this game.  All rights reserved.  (Please, don't come after me, Namco!)