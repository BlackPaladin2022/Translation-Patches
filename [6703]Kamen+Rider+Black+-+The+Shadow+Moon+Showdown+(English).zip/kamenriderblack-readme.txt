-------------------------------------------------------------------------
-BlackPaladin's Kamen Rider Black Taiketsu Shadow Moon Translation Patch-
-------------------------------------------------------------------------

*********************************************
*Kamen Rider Black: The Shadow Moon Showdown*
*********************************************

Kamen Rider Black is the eighth of the Kamen Rider tokusatsu series, airing on Japanse televison back in 1987.  Since it was announced recently that Kamen Rider Black was licensed by Discotek Media, I thought of making a quick translation patch for the game based on series of the same name.  

This game was released for the Famicom Disk System in 1988.  It's a platformer where Kamen Rider Black is to fight multiple Gorgom mutants until he faces the final boss, Shadow Moon.

Patching Instructions:

The patch comes in two flavors...

Kamen Rider Black - The Shadow Moon Showdown (English).ips
--This patch requires a clean and unaltered "Kamen Rider Black: Taiketsu Shadow Moon" FDS ROM (IPS Format)
Kamen Rider Black - The Shadow Moon Showdown (English).bps
--This patch requires a clean and unaltered "Kamen Rider Black: Taiketsu Shadow Moon" FDS ROM (BPS Format)

Be sure to use either patch on an FDS ROM (131,016 bytes) with a header.  Where to find said ROM is up to you.  I cannot tell you where to look for it.

The ROM has to have the following hashes:

File SHA-1: A9E7E53CB13DA3F8FF1EB27560E4543B6CC2F11F
File CRC32: E6F3B2AD
ROM SHA-1: BFE8B644FAB411216614381649F0BC84F8CCCB46
ROM CRC32: 566C6DDF

After applying either patch, it should have the following hashes:

File SHA-1: 1E27FA730F48281B0BA702753D78D42F543F3244
File CRC32: BA2FFE88
ROM SHA-1: FCF56942C1D2BA7D23C84792582F70C613A016C5
ROM CRC32: AB021FA

What has been translated?

The title screen
font changed
English text in the game fixed

v1.0
Initial release

Special Thanks:
Bootleg Porygon (He helped with the red text in the title screen)
abridgewater (He translated the word "Taiketsu")
YY-CHAR team (used this program to change graphics in the ROM)
WindHex32 team (used this hex editor to change bytes in the ROM)
