This is just a simple hack for the FDS version of Solomon's Key (Solomon no Kagi).  The title screen from the US version of the ROM was applied to the FDS version. No other modifications were made.  Just make sure to use either IPS or BPS patch (not both) to the following FDS ROM (with no header)...

File/ROM SHA-1: B06BFF43FCCEEEB789BE73C96960E6947EEAF75F
File/ROM CRC32: 9C2E3999

The end result should be the ROM with the following hashes...

File/ROM SHA-1: D80C4F601BB2CE146FE471990360AAAA44F2AB72
File/ROM CRC32: 71464036

Special thanks to Tecmo for releasing such an amazing puzzle game.  (So please don't come after me!)
