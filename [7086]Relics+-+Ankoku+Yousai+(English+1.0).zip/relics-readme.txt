------------------------------------------------------------
-BlackPaladin's Relics: Dark Fortress FDS Translation Patch-
------------------------------------------------------------

***********************
*Relics: Ankoku Yousai*
***********************

"Relics: Ankoku Yousai" is the second of a series of action-adventure games and the only Relics game released on a home console. (The other Relics games were released on Japanese PCs.)  In the second Relics game, you play the role of a spirit who can possess the bodies of certain characters in the game and inherit their abilities.  You, as this spirit, must fight within the dark fortress and face the enemies therein to rescue the Princess of Radiance.

One thing I should warn you about this game... it's hard.  Very hard!  But only because of how the main character moves.  Also, being a Famicom Disk System game, you'll be bombarded with MANY loading times.  Sometimes, you'll have to flip to side A, then to side B, and back to side A again for the game to load assets and continue playing.  This is the first game Bothtec released on a video game console. (Bothtec released game for Japanese PCs prior to this.)

The patch requires the ROM with the following hashes...

File/ROM SHA-1: 6BFF8CFD463B1EB91AEC5BB427C60A84A4DB34A8
File/ROM CRC32: 5DE87797

What's done?

The few Japanese lines are translated into English
Title Screen Translated

v0.9

Translated text

v1.0

Translated title screen inserted (Thanks to Raccoon Sam)
Utilities for compressing/decompressing graphics (written in Python) are provided, written by Raccoon Sam
Table file for text included

Special Thanks:

Raccoon Sam (Inserting translated title screen and provided utilities to compress and decompress the title screen graphics) 
FCE Ultra Team (Used their emulator for testing and hacking)
Mesen Team (Used their emulator for testing and hacking)
WindHex32 Team (Used their hex editor for hacking)
YY-Char Team (Used their program to edit the font graphics)

All credit to "relics: Ankoku Yousai" belong to Bothtec, and their respective creators and programmers.  This patch is mainly for pure entertainment for those who cannot enjoy the game.  All rights reserved.  (Bothtec, please don't come after me!)